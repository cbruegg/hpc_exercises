PROJECT_HOMEPAGE_URL
--------------------

The homepage URL of the project.

This is the homepage URL given to the most recently called :command:`project`
command in the current directory scope or above.  To obtain the homepage URL
of the top level project, see the :variable:`CMAKE_PROJECT_HOMEPAGE_URL`
variable.
