CTEST_SVN_UPDATE_OPTIONS
------------------------

Specify the CTest ``SVNUpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
