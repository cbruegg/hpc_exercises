CMAKE_VS_SDK_LIBRARY_DIRECTORIES
--------------------------------

This variable allows to override Visual Studio default Library Directories.
