CMAKE_LIBRARY_ARCHITECTURE
--------------------------

Target architecture library directory name, if detected.

This is the value of :variable:`CMAKE_<LANG>_LIBRARY_ARCHITECTURE` as detected
for one of the enabled languages.
