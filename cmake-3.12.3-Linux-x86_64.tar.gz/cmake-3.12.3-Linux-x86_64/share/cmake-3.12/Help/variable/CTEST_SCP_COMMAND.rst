CTEST_SCP_COMMAND
-----------------

Specify the CTest ``SCPCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
