CTEST_P4_CLIENT
---------------

Specify the CTest ``P4Client`` setting
in a :manual:`ctest(1)` dashboard client script.
