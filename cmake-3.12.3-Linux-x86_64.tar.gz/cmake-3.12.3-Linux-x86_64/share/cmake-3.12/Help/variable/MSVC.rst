MSVC
----

Set to ``true`` when the compiler is some version of Microsoft Visual
C++ or another compiler simulating Visual C++.  Any compiler defining
``_MSC_VER`` is considered simulating Visual C++.

See also the :variable:`MSVC_VERSION` variable.
