<PROJECT-NAME>_DESCRIPTION
--------------------------

Value given to the ``DESCRIPTION`` option of the most recent call to the
:command:`project` command with project name ``<PROJECT-NAME>``, if any.
