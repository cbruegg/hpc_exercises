CYGWIN
------

``True`` for Cygwin.

Set to ``true`` when using Cygwin.
